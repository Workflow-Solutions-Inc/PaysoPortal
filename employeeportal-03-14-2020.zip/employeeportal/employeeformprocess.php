<?php

session_start();
$userlogin = $_SESSION["user"];
$dataareaid = $_SESSION["defaultdataareaid"];
$logname = $_SESSION["logname"];
$logbio = $_SESSION["logbio"];
$lognum = $_SESSION["lognum"];
include("dbconn.php");


if($_GET["action"]=="refresh"){
	if($_GET["actmode"]=="schedule"){
		$fromdate=$_GET["slocFromdate"];
		$todate=$_GET["slocTodate"];

		$output='';
		//$output .= '<tbody>';
		$query = "SELECT daytype,date,weekday as day,shifttype,TIME_FORMAT(starttime,'%h:%i %p') as starttime,TIME_FORMAT(endtime,'%h:%i %p') as endtime 
					FROM shiftschedule
						where date between '$fromdate' and '$todate'
						and workerid = '$lognum'
						order by date";
		$result = $conn->query($query);
		$rowclass = "rowA";
		$rowcnt = 0;
		while ($row = $result->fetch_assoc())
		{
			$rowcnt++;
				if($rowcnt > 1) { $rowcnt = 0; $rowclass = "rowB"; }
				else { $rowclass = "rowA";}
			$output .= '
			<tr class="'.$rowclass.'">
				<td style="width:20px;" class="text-center"><span class="fa fa-angle-right"></span></td>
				<td style="width:16%;">'.$row["daytype"].'</td>
				<td style="width:16%;">'.$row["date"].'</td>
				<td style="width:16%;">'.$row["day"].'</td>
				<td style="width:16%;">'.$row["shifttype"].'</td>
				<td style="width:16%;">'.$row["starttime"].'</td>
				<td style="width:16%;">'.$row["endtime"].'</td>
				
			</tr>';
		}
		//$output .= '</tbody>';
		echo $output;
		//header('location: process.php');
	}
	else if($_GET["actmode"]=="attendance"){
		$fromdateAtt=$_GET["slocFromdate"];
		$todateAtt=$_GET["slocTodate"];

		$output2='';
		//$output .= '<tbody>';
		$query2 = "SELECT consol.date,TIME_FORMAT(intbl.timein,'%h:%i %p') as timein,TIME_FORMAT(outtbl.timeout,'%h:%i %p') as timeout,consol.bioid
					FROM 
						consolidationtable consol
						left join (select date,MAX(time) as timeout,bioid,type from consolidationtable where type = 1
						group by date,bioid,type) outtbl on consol.BioId = outtbl.bioid and consol.Date = outtbl.date

						left join (select date,MIN(time) as timein,bioid,type from consolidationtable where type = 0
						group by date,bioid,type) intbl on consol.BioId = intbl.bioid and consol.Date = intbl.date

						where consol.bioid = '$logbio' and consol.date between '$fromdateAtt' and '$todateAtt'

						group by consol.date,consol.bioid";
		$result2 = $conn->query($query2);
		$rowclass = "rowA";
		$rowcnt = 0;
		while ($row2 = $result2->fetch_assoc())
		{
			$rowcnt++;
				if($rowcnt > 1) { $rowcnt = 0; $rowclass = "rowB"; }
				else { $rowclass = "rowA";}
			$output2 .= '
			<tr class="'.$rowclass.'">
				<td style="width:20px;" class="text-center"><span class="fa fa-angle-right"></span></td>
				<td style="width:33%;">'.$row2["date"].'</td>
				<td style="width:33%;">'.$row2["timein"].'</td>
				<td style="width:33%;">'.$row2["timeout"].'</td>
				
			</tr>';
		}
		//$output .= '</tbody>';
		echo $output2;
		//header('location: process.php');
	}
}